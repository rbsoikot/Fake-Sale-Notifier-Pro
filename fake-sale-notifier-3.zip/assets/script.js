jQuery(function($) {
    let notificationTimeout;
    let isVisible = false;
    const { ajax_url, initial_delay, display_duration, interval_time, animation_speed } = fsn_data;
    
    function showNotification(data) {
        if (isVisible || data.error) return;
        
        const popup = $('#fsn-popup');
        popup.html(`
            <div class="fsn-notification">
                <div class="fsn-avatar">${data.initials}</div>
                <div class="fsn-content">
                    <div class="fsn-header">
                        <strong>${data.name}</strong>
                        <span class="fsn-time">${data.time_ago}</span>
                    </div>
                    <div class="fsn-message">purchased <strong>${data.product}</strong></div>
                    <div class="fsn-location">from ${data.address}, ${data.country}</div>
                </div>
                <button class="fsn-close">&times;</button>
            </div>
        `);
        
        popup.stop(true, true)
            .removeClass('fsn-hidden')
            .css({ opacity: 0, left: '-100px' })
            .animate({ 
                opacity: 1,
                left: '20px'
            }, animation_speed);
        
        isVisible = true;
        
        notificationTimeout = setTimeout(hideNotification, display_duration);
    }
    
    function hideNotification() {
        $('#fsn-popup').stop(true, true).animate({
            opacity: 0,
            left: '-100px'
        }, animation_speed, function() {
            $(this).addClass('fsn-hidden');
            isVisible = false;
        });
    }
    
    function fetchNotification() {
        if (isVisible) return;
        
        $.post(ajax_url, { action: 'fsn_get_popup' })
            .done(showNotification)
            .fail(() => setTimeout(fetchNotification, 5000));
    }
    
    // Close button handler
    $(document).on('click', '.fsn-close', function() {
        clearTimeout(notificationTimeout);
        hideNotification();
    });
    
    // Initial setup
    setTimeout(fetchNotification, initial_delay);
    setInterval(fetchNotification, interval_time);
});