<?php
add_action('wp_ajax_fsn_get_popup', 'fsn_get_popup');
add_action('wp_ajax_nopriv_fsn_get_popup', 'fsn_get_popup');

function fsn_get_popup() {
    // Get products from options or use empty array
    $products = explode("\n", get_option('fsn_products', ''));
    $products = array_filter(array_map('trim', $products));
    
    // If no products set, return empty to prevent showing notification
    if (empty($products)) {
        wp_send_json(['error' => 'No products configured']);
    }

    $names = explode("\n", get_option('fsn_names', ''));
    $addresses = explode("\n", get_option('fsn_addresses', ''));
    $countries = explode("\n", get_option('fsn_countries', ''));

    // Filter out empty lines
    $names = array_filter(array_map('trim', $names));
    $addresses = array_filter(array_map('trim', $addresses));
    $countries = array_filter(array_map('trim', $countries));

    // If empty, use defaults
    if (empty($names)) $names = ['John Doe', 'Jane Smith', 'Robert Johnson'];
    if (empty($addresses)) $addresses = ['New York', 'London', 'Tokyo'];
    if (empty($countries)) $countries = ['USA', 'UK', 'Japan'];

    shuffle($names);
    shuffle($addresses);
    shuffle($countries);
    shuffle($products);

    $name = $names[0];
    $address = $addresses[0];
    $country = $countries[0];
    $product = $products[0];

    $name_parts = explode(' ', $name);
    $initials = strtoupper(substr($name_parts[0], 0, 1) . substr($name_parts[1] ?? '', 0, 1));
    $time_ago = wp_rand(1, 15) . ' minutes ago';  // Changed rand() to wp_rand()

    wp_send_json([
        'name' => $name,
        'address' => $address,
        'country' => $country,
        'initials' => $initials,
        'product' => $product,
        'time_ago' => $time_ago
    ]);
}