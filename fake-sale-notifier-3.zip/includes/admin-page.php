<?php
function fsn_admin_menu() {
    add_menu_page(
        'Fake Sale Notifier Pro', 
        'Sale Notifier Pro', 
        'manage_options', 
        'fsn-settings', 
        'fsn_admin_page',
        'dashicons-megaphone',
        80
    );
}
add_action('admin_menu', 'fsn_admin_menu');

function fsn_admin_page() {
    if (isset($_POST['fsn_settings'])) {
        check_admin_referer('fsn_save_settings');
        
        // Update options with proper validation and unslashing
        if (isset($_POST['fsn_names'])) {
            update_option('fsn_names', sanitize_textarea_field(wp_unslash($_POST['fsn_names'])));
        }
        
        if (isset($_POST['fsn_addresses'])) {
            update_option('fsn_addresses', sanitize_textarea_field(wp_unslash($_POST['fsn_addresses'])));
        }
        
        if (isset($_POST['fsn_countries'])) {
            update_option('fsn_countries', sanitize_textarea_field(wp_unslash($_POST['fsn_countries'])));
        }
        
        if (isset($_POST['fsn_products'])) {
            update_option('fsn_products', sanitize_textarea_field(wp_unslash($_POST['fsn_products'])));
        }
        
        update_option('fsn_initial_delay', isset($_POST['fsn_initial_delay']) ? absint($_POST['fsn_initial_delay']) : 5);
        update_option('fsn_display_duration', isset($_POST['fsn_display_duration']) ? absint($_POST['fsn_display_duration']) : 6);
        update_option('fsn_interval_time', isset($_POST['fsn_interval_time']) ? absint($_POST['fsn_interval_time']) : 20);
        update_option('fsn_show_on_pages', isset($_POST['fsn_show_on_pages']) ? sanitize_text_field(wp_unslash($_POST['fsn_show_on_pages'])) : 'all');
        
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
    }

    $settings = [
        'names' => get_option('fsn_names', ''),
        'addresses' => get_option('fsn_addresses', ''),
        'countries' => get_option('fsn_countries', ''),
        'products' => get_option('fsn_products', ''),
        'initial_delay' => get_option('fsn_initial_delay', 5),
        'display_duration' => get_option('fsn_display_duration', 6),
        'interval_time' => get_option('fsn_interval_time', 20),
        'show_on_pages' => get_option('fsn_show_on_pages', 'all')
    ];
    ?>
    
    <div class="wrap">
        <h1 class="fsn-admin-title">
            <span class="dashicons dashicons-megaphone"></span> 
            Fake Sale Notifier Pro
        </h1>
        
        <div class="fsn-admin-container">
            <div class="fsn-admin-main">
                <form method="post">
                    <?php wp_nonce_field('fsn_save_settings'); ?>
                    
                    <div class="fsn-form-section">
                        <h2>Notification Content</h2>
                        
                        <div class="fsn-form-group">
                            <label for="fsn_names">Customer Names (one per line)</label>
                            <textarea name="fsn_names" id="fsn_names" class="fsn-textarea"><?php echo esc_textarea($settings['names']); ?></textarea>
                        </div>
                        
                        <div class="fsn-form-group">
                            <label for="fsn_addresses">Addresses (one per line)</label>
                            <textarea name="fsn_addresses" id="fsn_addresses" class="fsn-textarea"><?php echo esc_textarea($settings['addresses']); ?></textarea>
                        </div>
                        
                        <div class="fsn-form-group">
                            <label for="fsn_countries">Countries (one per line)</label>
                            <textarea name="fsn_countries" id="fsn_countries" class="fsn-textarea"><?php echo esc_textarea($settings['countries']); ?></textarea>
                        </div>
                        
                        <div class="fsn-form-group">
                            <label for="fsn_products">Your Product Names (one per line)</label>
                            <textarea name="fsn_products" id="fsn_products" class="fsn-textarea"><?php echo esc_textarea($settings['products']); ?></textarea>
                            <p class="description">These are the products that will appear in notifications</p>
                        </div>
                    </div>
                    
                    <div class="fsn-timing-settings">
                        <h3>Display Settings</h3>
                        
                        <div class="fsn-timing-grid">
                            <div class="fsn-timing-item">
                                <label for="fsn_initial_delay">Initial Delay (seconds)</label>
                                <input type="number" name="fsn_initial_delay" id="fsn_initial_delay" 
                                       value="<?php echo esc_attr($settings['initial_delay']); ?>" min="1" max="60">
                            </div>
                            
                            <div class="fsn-timing-item">
                                <label for="fsn_display_duration">Display Duration (seconds)</label>
                                <input type="number" name="fsn_display_duration" id="fsn_display_duration" 
                                       value="<?php echo esc_attr($settings['display_duration']); ?>" min="1" max="60">
                            </div>
                            
                            <div class="fsn-timing-item">
                                <label for="fsn_interval_time">Interval Time (seconds)</label>
                                <input type="number" name="fsn_interval_time" id="fsn_interval_time" 
                                       value="<?php echo esc_attr($settings['interval_time']); ?>" min="5" max="3600">
                            </div>
                        </div>
                        
                        <div class="fsn-form-group" style="margin-top:20px;">
                            <label for="fsn_show_on_pages"><strong>Show notifications on:</strong></label>
                            <select name="fsn_show_on_pages" id="fsn_show_on_pages" class="fsn-select">
                                <option value="all" <?php selected($settings['show_on_pages'], 'all'); ?>>All Pages</option>
                                <option value="selected" <?php selected($settings['show_on_pages'], 'selected'); ?>>Only Selected Pages</option>
                            </select>
                            <p class="description">Use the <code>[fsn_notifications]</code> shortcode on pages where you want notifications to appear</p>
                        </div>
                    </div>
                    
                    <input type="hidden" name="fsn_settings" value="1">
                    <button type="submit" class="button button-primary">Save Settings</button>
                </form>
            </div>
            
            <div class="fsn-admin-sidebar">
                <div class="fsn-preview-box">
                    <h3>Live Preview</h3>
                    <div class="fsn-notification-preview">
                        <div class="fsn-avatar">JD</div>
                        <div class="fsn-content">
                            <div class="fsn-header">
                                <strong>John Doe</strong>
                                <span class="fsn-time">2 minutes ago</span>
                            </div>
                            <div class="fsn-message">purchased <strong><?php echo !empty($settings['products']) ? esc_html(explode("\n", $settings['products'])[0]) : 'Your Product'; ?></strong></div>
                            <div class="fsn-location">from New York, USA</div>
                        </div>
                    </div>
                </div>
                
                <div class="fsn-settings-info">
                    <h3>Current Settings</h3>
                    <ul>
                        <li><strong>Initial Delay:</strong> <?php echo esc_html($settings['initial_delay']); ?>s</li>
                        <li><strong>Display Duration:</strong> <?php echo esc_html($settings['display_duration']); ?>s</li>
                        <li><strong>Interval Time:</strong> <?php echo esc_html($settings['interval_time']); ?>s</li>
                        <li><strong>Display On:</strong> <?php echo esc_html($settings['show_on_pages'] === 'all' ? 'All Pages' : 'Selected Pages'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php
}