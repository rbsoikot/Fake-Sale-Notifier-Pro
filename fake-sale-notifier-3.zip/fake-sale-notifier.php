<?php
/*
Plugin Name: Fake Sale Notifier Pro
Description: Displays professional fake sale notifications with customizable timing.
Version: 1.5
Author: RB Soikot
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

if (!defined('ABSPATH')) exit;

define('FSN_PATH', plugin_dir_path(__FILE__));
define('FSN_URL', plugin_dir_url(__FILE__));
define('FSN_VERSION', '1.5');

// Admin & AJAX handlers
include_once FSN_PATH . 'includes/admin-page.php';
include_once FSN_PATH . 'includes/ajax-handler.php';

// Enqueue admin styles
function fsn_admin_styles() {
    wp_enqueue_style(
        'fsn-admin-style', 
        FSN_URL . 'assets/admin-style.css',
        [],
        FSN_VERSION
    );
}
add_action('admin_enqueue_scripts', 'fsn_admin_styles');

// Enqueue frontend assets only when needed
function fsn_enqueue_assets() {
    $show_on_pages = get_option('fsn_show_on_pages', 'all');
    $post = get_post();
    $has_shortcode = $post && has_shortcode($post->post_content, 'fsn_notifications');

    if ($show_on_pages === 'all' || ($show_on_pages === 'selected' && $has_shortcode)) {
        wp_enqueue_style(
            'fsn-style', 
            FSN_URL . 'assets/style.css',
            [],
            FSN_VERSION
        );
        
        wp_enqueue_script(
            'fsn-script', 
            FSN_URL . 'assets/script.js', 
            ['jquery'], 
            FSN_VERSION,
            true
        );
        
        wp_localize_script('fsn-script', 'fsn_data', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'initial_delay' => get_option('fsn_initial_delay', 5) * 1000,
            'display_duration' => get_option('fsn_display_duration', 6) * 1000,
            'interval_time' => get_option('fsn_interval_time', 20) * 1000,
            'animation_speed' => 300
        ]);
    }
}
add_action('wp_enqueue_scripts', 'fsn_enqueue_assets');

// Display HTML container only when needed
function fsn_notification_popup_html() {
    $show_on_pages = get_option('fsn_show_on_pages', 'all');
    $post = get_post();
    $has_shortcode = $post && has_shortcode($post->post_content, 'fsn_notifications');

    if ($show_on_pages === 'all' || ($show_on_pages === 'selected' && $has_shortcode)) {
        echo '<div id="fsn-popup" class="fsn-hidden"></div>';
    }
}
add_action('wp_footer', 'fsn_notification_popup_html');

// Shortcode for selected pages
function fsn_notifications_shortcode() {
    return '';
}
add_shortcode('fsn_notifications', 'fsn_notifications_shortcode');
